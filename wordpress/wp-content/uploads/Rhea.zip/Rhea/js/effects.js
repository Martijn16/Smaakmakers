jQuery(document).ready(function() {
Cufon.replace('.blogname h1,.title h2,h2.pagetitle,h3.sidetitl', { fontFamily: 'Qlassik Bold' });
});