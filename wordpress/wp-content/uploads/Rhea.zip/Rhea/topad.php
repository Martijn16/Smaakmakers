
<div class="headbanner">
<?php $ad2 = get_option('rhea_ad2'); echo stripslashes($ad2); ?>
</div>
<div class="clear"></div>