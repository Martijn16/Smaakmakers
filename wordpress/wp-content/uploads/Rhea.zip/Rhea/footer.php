</div>
<div class="clear"></div>
<div id="footer">
<div class="fcred">
Copyright &copy; <?php echo date('Y');?> <a href="<?php
bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?>"><?php
bloginfo('name'); ?></a> - <?php bloginfo('description'); ?>.<br/>
Powered by WordPress &amp; <a href="http://topwpthemes.com/rhea/" title="Free WordPress Theme - Rhea"><?php echo
get_current_theme() ?></a>. WordPress Theme designed by <a
href="http://www.fabthemes.com" title="WordPress Themes
Designs">FabThemes.com</a>
</div>
<?php wp_footer(); ?>
<div class='clear'></div>	
</div>
</div>	
</body>
</html>      