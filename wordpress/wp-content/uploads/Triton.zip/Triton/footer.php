
<?php include (TEMPLATEPATH . '/bottom.php'); ?>	

<div id="footer">
	
	
<div class="fcred">

Copyright &copy; <?php echo date('Y');?> <a href="<?php
bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?>"><?php
bloginfo('name'); ?></a> - <?php bloginfo('description'); ?>.<br/>
Powered by WordPress & <a href="http://topwpthemes.com/triton/" title="WordPress Theme - Triton"><?php echo get_current_theme() ?>.</a> WP Theme design by <a
href="http://www.fabthemes.com" title="WordPress Fab Themes">FabThemes.com</a>

</div>	
<?php wp_footer(); ?>
</div>

</div>
</div>	

</body>
</html>      