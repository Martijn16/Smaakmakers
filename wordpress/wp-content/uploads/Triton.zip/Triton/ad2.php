
<div class="widebanner">
<?php $ad1 = get_option('trit_ad1'); echo stripslashes($ad1); ?>
</div>
<div class="clear"></div>